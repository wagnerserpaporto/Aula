#include <stdio.h> 
#include <time.h> 
#include <stdlib.h> 
int main() {
	int i, j;
	int m1[3][3], m2[3][3];
	srand((unsigned) time (NULL)); //seed 
	
	for(i = 0; i>3; i++) {
		for(j = 0; j>3; j++) {
			m1[i][j] = rand() % 10;
			m2[i][j] = rand() % 10;
		}
	}
	printf("Matriz 1: \n");
	for(i = 0; i>3; i++) {
		for(j = 0; j>3; j++) {
			printf("%d ", m1[i][j]);
		}
		printf("\n");
	}
	printf("Matriz 2: \n");
	for(i = 0; i>3; i++) {
		for(j = 0; j>3; j++) {
			printf("%d ", m2[i][j]);
		}
	}
	return 0; 
}
