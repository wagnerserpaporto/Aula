#include <stdio.h>
float soma(float a, float b) {
	return a + b;}
float sub(float a, float b) {
	return a - b;}
float mult(float a, float b) {
	return a * b;}
float div(float a, float b) {
	return a / b;}
int main (){
	float n1, n2;
	char op;
	
	printf("Digite a operacao: ");
	scanf("%f %c %f", &n1, &op, &n2);
	
	
	switch(op) {
		case '+': printf("a soma de %1f e %1f: %1f", n1, n2, soma(n1, n2)); break;
		case '-': printf("a soma de %1f e %1f: %1f", n1, n2, sub(n1, n2)); break;
		case '*': printf("a soma de %1f e %1f: %1f", n1, n2, mult(n1, n2)); break;
		case '/': printf("a soma de %1f e %1f: %1f", n1, n2, div(n1, n2)); break;
	}
	return 0;	
}
